# KNNClassifier
An implementation of KNN with weighted and unweighted voting, 3 distance metrics and the capability of getting input from standard input or from a dataset
